import numpy as np
from graphviz import Digraph
import os

def index_of(sub_arr,arr):
    arr = arr.tolist()
    jump = len(sub_arr)
    # print('sub_arr = ',sub_arr)
    # print('arr = ',arr)
    for i in range(0,len(arr[0])):
        if arr[0][i:i+jump] == sub_arr:
            return i + jump
    return -1

def process_df(field):
    res = []
    for s in field:
        s = s.replace('[','').replace(']','').strip()
        # print('s = ', s)
        first = float(s.split()[0])
        second = float(s.split()[1])
        res.append([first,second])
    return np.array(res)

def process_df1(field):
    res = []
    for s in field:
        s = s.replace('[','').replace(']','').replace(',','').strip()
        # print('s = ', s)
        first = float(s.split()[0])
        second = float(s.split()[1])
        res.append([first,second])
    return np.array(res)

def get_active_states(automat,startState, startName = 'Start'):
    visited = set()
    def active_states(state, visited):
        if state.name == 'P':
            return

        visited.add(state.name)
        for t in state.transition:
            if state.transition[t] == None or state.transition[t].name in visited:
                continue
            active_states(state.transition[t],visited)

    startState = automat.states[startName]

    active_states(startState,visited)
    return visited

def automat_gen_string(automat,startName = 'Start', th = 3):
    visited = set()
    paths = []
    def active_states(path, prev_input,state, visited):

        if state.name == 'P':
            paths.append(path)
            return
        if state.name not in visited:
            state.input_count = {prev_input:1}
            visited.add(state.name)
        else:
            if prev_input in state.input_count:
                if state.input_count[prev_input] > th:
                    return
                state.input_count[prev_input] += 1
            else:
                state.input_count[prev_input] = 1

        for t in state.transition:
            active_states(path + '-' + t, t, state.transition[t],visited)

    startState = automat.states[startName]
    active_states("S","",startState,visited)
    return paths

def automat_gen_string_dfs(automat,startName = 'Start', th = 1):
    visited = set()
    paths = []
    def process(path, prev_states,state, visited):

        if state.name == 'P':
            paths.append(path + "-P")
            return
        if state.name not in visited:
            state.cycles = {}
            visited.add(state.name)

        if state.name in prev_states:
            cycle_path = prev_states[prev_states.rindex(state.name):]

            if cycle_path in state.cycles:
                state.cycles[cycle_path] += 1
            else:
                state.cycles[cycle_path] = 1

            cycle_counts = {}

            prev_states_str = prev_states
            for cycle_path in state.cycles:
                cycle_counts[cycle_path] = prev_states.count(cycle_path)


            if state.name == 'Start':
                print('-------')
                print('state_cycles = ',state.name,state.cycles)
                print('prev_states: ',prev_states)
                print('cycle_counts = ',cycle_counts)
            if any([True if cycle_counts[x] > th else False for x in cycle_counts]):
                return


        for t in state.transition:
            process(path + '-' + t, prev_states + "-" + state.name, state.transition[t],visited)

    startState = automat.states[startName]
    process("S","",startState,visited)
    # print('path len = ',len(paths))
    return paths


def automat_gen_string_dfs1(startState, startName='Start', len_th=30,size_th = 100):
    visited = set()
    paths = []
    unfinished_paths = []

    def process(path, prev_states, state, visited):

        if state.name == 'P':
            paths.append(path + "-P")
            return
        if len(path) > len_th:
            unfinished_paths.append(path)
            return

        if len(unfinished_paths) > size_th:
            return

        if state.name not in visited:
            visited.add(state.name)

        for t in state.transition:
            process(path + '-' + t, prev_states + "-" + state.name, state.transition[t], visited)

    # startState = automat.states[startName]
    process("S", "", startState, visited)
    # print('path len = ', len(paths))
    return paths, unfinished_paths

def automat_gen_string_bfs(startState, th = 20, len_th = 2000):

    def process(state, th):
        res_path = []
        queue = [state]
        paths = [state.name]
        prev_states = [state.name]
        # curr_prevs = [startName]
        while len(queue) > 0:
            pop_state = queue.pop(0)
            print('[db] in while loop...', len(paths), len(queue), len(prev_states),pop_state.name)
            curr_path = paths.pop(0)
            curr_prevs = prev_states.pop(0)
            if pop_state.name == 'P':
                print('curr_path = ',curr_path)
                res_path.append(curr_path + '-P')
            if len(curr_path.split("-")) > th or len(paths) > len_th:
                print('[db] breaking...',len(curr_path.split("-")),len_th)
                res_path.append(curr_path + '-P')
                break
            for t in pop_state.transition:
                print('[db] added...', t,pop_state.transition[t].name)
                queue.append(pop_state.transition[t])
                # print('[db] queue = ',[s.name for s in queue])
                paths.append(curr_path + "-" + str(t))
                prev_states.append(curr_prevs + "-" + pop_state.transition[t].name)
        return res_path

    # startState = automat.states[startName]
    paths = process(startState,th)
    # print('path len = ',len(paths))
    return paths

def automat_gen_string_bfs1(startState, th = 15, len_th = 100000):

    def process(state, th):
        res_path, unfinished_paths = [], []
        queue = [state]
        paths = [state.name]
        prev_states = [state.name]
        # curr_prevs = [startName]
        while len(queue) > 0:
            pop_state = queue.pop(0)
            # print('[db] in while loop...', len(paths), len(queue), len(prev_states),pop_state.name)
            curr_path = paths.pop(0)
            curr_prevs = prev_states.pop(0)
            # print('curr_path = ', curr_path)
            if pop_state.name == 'P':
                # print('dest curr_path = ',curr_path)
                res_path.append(curr_path + '-P')
            if len(curr_path.split("-")) > th:
                # print('[db] continue...',len(curr_path.split("-")))
                # res_path.append(curr_path + '-P')
                unfinished_paths.append(curr_path)
                continue

            if len(paths) > len_th:
                # print('[db] breaking...',len(curr_path.split("-")),len_th)
                break

            for t in pop_state.transition:
                # print('[db] added...', t,pop_state.transition[t].name)
                queue.append(pop_state.transition[t])
                # print('[db] queue = ',[s.name for s in queue])
                paths.append(curr_path + "-" + str(t))
                prev_states.append(curr_prevs + "-" + pop_state.transition[t].name)
        return res_path, unfinished_paths

    # startState = automat.states[startName]
    res_path, unfinished_paths = process(startState,th)
    # print('path len = ',len(res_path))
    return res_path, unfinished_paths

def automat_gen_string_bfs2(startState, th = 25, len_th = 10000, cycle_th = 400):

    def process(state, th):
        res_path, unfinished_paths = [], []
        visited = set()
        queue = [state]
        paths = [state.name]
        prev_states = [""]
        visited.add(state.name)
        cycle_counts = {}
        # curr_prevs = [startName]
        while len(queue) > 0:
            pop_state = queue.pop(0)
            # print('[db] in while loop...', len(paths), len(queue), len(prev_states),pop_state.name)
            curr_path = paths.pop(0)
            curr_prevs = prev_states.pop(0)
            print('curr_path = ', curr_path)
            # if pop_state.name in visited:
            # 	pop_state.cycles = {}
            curr_prevs_list = curr_prevs.split("-")
            if pop_state.name in curr_prevs_list:

                cycle_path = curr_prevs[curr_prevs.rindex(pop_state.name):]
                # print('cycle_path = ',curr_prevs_list,cycle_path,pop_state.name)

                if cycle_path in cycle_counts:
                    cycle_counts[cycle_path] += 1
                else:
                    cycle_counts[cycle_path] = 1
                # print('cycle_counts = ', cycle_counts)
                if cycle_counts[cycle_path] > cycle_th:
                    print('cycling continue')
                    continue
            if pop_state.name == 'P':
                # print('dest curr_path = ',curr_path)
                res_path.append(curr_path + '-P')
                continue
            if len(curr_path.split("-")) > th:
                # print('[db] continue...',len(curr_path.split("-")))
                # res_path.append(curr_path + '-P')
                unfinished_paths.append(curr_path)
                continue

            if len(paths) > len_th:
                print('[db] breaking...',len(curr_path.split("-")),len_th)
                break

            for t in pop_state.transition:
                print('[db] added...', t,pop_state.transition[t].name)
                queue.append(pop_state.transition[t])
                visited.add(pop_state.transition[t].name)
                print('[db] queue = ',[s.name for s in queue])
                paths.append(curr_path + "-" + str(t))
                prev_states.append(curr_prevs + "-" + pop_state.name)
        return res_path, unfinished_paths

    # startState = automat.states[startName]
    res_path, unfinished_paths = process(startState,th)
    # print('path len = ',len(res_path))
    return res_path, unfinished_paths

def automat_gen_string_bfs3(startState, th = 15, len_th = 10000, cycle_th = 10):

    def process(state, th):
        res_path, unfinished_paths = [], []
        visited = set()
        queue = [state]
        paths = [state.name]
        prev_states = [""]
        visited.add(state.name)
        cycle_counts = {}
        # curr_prevs = [startName]
        while len(queue) > 0:
            pop_state = queue.pop(0)
            # print('[db] in while loop...', len(paths), len(queue), len(prev_states),pop_state.name)
            curr_path = paths.pop(0)
            curr_prevs = prev_states.pop(0)
            # print('curr_path = ', curr_path)
            # if pop_state.name in visited:
            # 	pop_state.cycles = {}
            curr_prevs_list = curr_prevs.split("-")
            if pop_state.name in curr_prevs_list:

                cycle_path = curr_prevs[curr_prevs.rindex(pop_state.name):]
                # print('cycle_path = ',curr_prevs_list,cycle_path,pop_state.name)

                if cycle_path in cycle_counts:
                    cycle_counts[cycle_path] += 1
                else:
                    cycle_counts[cycle_path] = 1
                # print('cycle_counts = ', cycle_counts)
                if cycle_counts[cycle_path] > cycle_th:
                    # print('cycling continue')
                    unfinished_paths.append(curr_path)
                    continue
            if pop_state.name == 'P':
                # print('dest curr_path = ',curr_path)
                res_path.append(curr_path + '-P')
                continue
            if len(curr_path.split("-")) > th:
                # print('[db] continue...',len(curr_path.split("-")))
                # res_path.append(curr_path + '-P')
                unfinished_paths.append(curr_path)
                continue

            if len(paths) > len_th:
                # print('[db] breaking...',len(curr_path.split("-")),len_th)
                break

            for t in pop_state.transition:
                # print('[db] added...', t,pop_state.transition[t].name)
                if pop_state.transition[t] == None:
                    continue
                queue.append(pop_state.transition[t])
                visited.add(pop_state.transition[t].name)
                # print('[db] queue = ',[s.name for s in queue])
                paths.append(curr_path + "-" + str(t))
                prev_states.append(curr_prevs + "-" + pop_state.name)
        return res_path, unfinished_paths

    # startState = automat.states[startName]
    res_path, unfinished_paths = process(startState,th)
    # print('path len = ',len(res_path))
    return res_path, unfinished_paths

def automat_gen_string_bfs4suffix(startState, suffState, suff, th = 25, len_th = 10000, cycle_th = 400):

    def process(state, suffState, suff, th):
        res_path, suffPaths, unfinished_paths = [], [], []
        visited = set()
        queue = [state]
        paths = [state.name]
        prev_states = [""]
        visited.add(state.name)
        cycle_counts = {}
        # curr_prevs = [startName]
        while len(queue) > 0:
            pop_state = queue.pop(0)
            # print('[db] in while loop...', len(paths), len(queue), len(prev_states),pop_state.name)
            curr_path = paths.pop(0)
            curr_prevs = prev_states.pop(0)
            # print('curr_path = ', curr_path)
            # if pop_state.name in visited:
            # 	pop_state.cycles = {}
            curr_prevs_list = curr_prevs.split("-")
            if pop_state.name in curr_prevs_list:

                cycle_path = curr_prevs[curr_prevs.rindex(pop_state.name):]
                # print('cycle_path = ',curr_prevs_list,cycle_path,pop_state.name)

                if cycle_path in cycle_counts:
                    cycle_counts[cycle_path] += 1
                else:
                    cycle_counts[cycle_path] = 1
                # print('cycle_counts = ', cycle_counts)
                if cycle_counts[cycle_path] > cycle_th:
                    # print('cycling continue')
                    unfinished_paths.append(curr_path)
                    continue
            if pop_state.name == 'P':
                # print('dest curr_path = ',curr_path)
                res_path.append(curr_path + '-P')
                continue

            if pop_state.name == suffState.name:
                # print('dest curr_path = ',curr_path)
                suffPaths.append(curr_path + "-" + suff)
                # continue

            if len(curr_path.split("-")) > th:
                # print('[db] continue...',len(curr_path.split("-")))
                # res_path.append(curr_path + '-P')
                unfinished_paths.append(curr_path)
                continue

            if len(paths) > len_th:
                # print('[db] breaking...',len(curr_path.split("-")),len_th)
                break

            for t in pop_state.transition:
                # print('[db] added...', t,pop_state.transition[t].name)
                queue.append(pop_state.transition[t])
                visited.add(pop_state.transition[t].name)
                # print('[db] queue = ',[s.name for s in queue])
                paths.append(curr_path + "-" + str(t))
                prev_states.append(curr_prevs + "-" + pop_state.name)
        return res_path, suffPaths, unfinished_paths

    # startState = automat.states[startName]
    res_path, suffPaths, unfinished_paths = process(startState,suffState,suff,th)
    # print('path len = ',len(res_path))
    return res_path, suffPaths, unfinished_paths

# def convert_data_x(x,alphabets):
#     d = {a:i for i,a in enumerate(alphabets)}
#     res = []
#     for ip in x:
#         res1 = []
#         for e in ip:
#             v = [0] * len(d)
#             v[d[e]] = 1
#             res1.append(v)
#         res.append(res1)
#     return res

def convert_data_x_todigit(x,alphabets):
    res = []
    for ip in x:
        res1 = []
        for e in ip:
            for i,d in enumerate(e):
                if str(d) == '1':
                    res1.append(alphabets[i])
        res.append(res1)
    return res

def convert_data_x(x,alphabets=['1','0']):
    d = {a:i for i,a in enumerate(alphabets)}
    res = []
    for ip in x:
        res1 = []
        for e in ip:
            v = [0] * len(d)
            v[d[e]] = 1
            res1.append(v)
        res.append(res1)
    return res

def draw_automat(automat,startState, startName = 'Start',name="automat"):
    dot = Digraph(comment=name, filename='fsm.gv')
    dot.attr(size='8,5')
    dot.attr('node', shape='circle')

    print('dot = ', dot)

    visited = set()
    # startState = automat.states[startName]

    dot.node(startName)

    def dfs_drawing(state, visited):
        if state.name == 'P' or state.name in visited:
            return
        dot.node(state.name)
        visited.add(state.name)
        for t in state.transition:
            # if state.transition[t].name in visited:
            # 	continue
            if state.transition[t] == None:
                continue

            dot.node(state.transition[t].name)
            dot.edge(state.name, state.transition[t].name, label=str(t))
            dfs_drawing(state.transition[t],visited)

    startState = automat.states['Start']
    dfs_drawing(startState,visited)
    # dot.node('1')
    # dot.node('2')
    # dot.node('3')
    # dot.node('4')
    # dot.node('5')
    # dot.node('6')
    #
    # dot.attr('node', shape='circle')
    # dot.edge('1', '2', label='1')
    # dot.edge('2', '3', label='2')
    # dot.edge('3', '4', label='2')
    # dot.edge('4', '5', label='2')
    # dot.edge('5', '6', label='2')
    # dot.edge('1', '6', label='2')

    print(dot.source)
    name = name.replace("\n","")
    dot.render(name + "_gv" , view=False, format='pdf')

import re
import random
def generate_data1(total_series_no = 20000):
    def arr_to_string(ipArr):
        returnStr = ""
        for e in ipArr:
            returnStr += str(e)
        return returnStr

    def str_to_arr(ipStr):
        return [int(e) for e in ipStr]

    seq_length = 15
    max_length = 100
    # total_series_no = 20000
    inp_arr = []
    inp_arr_str = []
    lbl_arr = []
    rdn = random.randint(1,10)

    for i in range(0,total_series_no):
        inp_a = arr_to_string(np.random.choice(2,max_length))
        inp_arr_str.append(inp_a[:seq_length])

    pos_sub_str = ["111","1111","11111"]
    neg_sub_str = ["1"*c for c in range(6,15)]

    count_pos = 0
    # _not_tomita_3 = re.compile("((0|1)*0)*1(11)*(0(0|1)*1)*0(00)*(1(0|1)*)*$")
    for a in inp_arr_str:
        # if re.search("11111", a) != None:
        if '11111' in a or '101010' in a:
            lbl_arr.append([1,0])
            count_pos+=1
        else:
            lbl_arr.append([0,1])
        inp_arr.append(str_to_arr(a))
    print('count pos, neg: ',count_pos,len(lbl_arr) - count_pos)
    return np.array(inp_arr),np.array(lbl_arr)

def generate_data2():
    alphabets = ['0','1']
    paths, lbls = [],[]
    maxlength = 10
    count = [0,0]
    def genstr(s):
        if len(s) > 0:
            paths.append(s)
            # if '101010' in s:
            if re.search("1(10)+1", s) != None:
            # if (s.count("10") >= 2):
                lbls.append([1, 0])
                count[0]+=1
            else:
                lbls.append([0, 1])
                count[1] += 1
        if len(s) > maxlength:
            return

        # if re.search("(1)*", s) != None:

        for d in alphabets:
            genstr(s + d)

    genstr("")
    print('count ',count)
    return paths, lbls

if __name__ == "__main__":
    a = [[0,1,1,1,0,0,1,0,1,0]]
    print(index_of([1,1,1],a))
    print(index_of([1, 0 ,0,0], a))