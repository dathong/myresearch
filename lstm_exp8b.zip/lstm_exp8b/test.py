f = open('long_states_df.csv','w')
f.write('test \n')
print('done')