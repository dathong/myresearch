class Config:
    stateSize = 10

# print(Config.stateSize)