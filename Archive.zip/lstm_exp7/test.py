class Cat(object):
	def __init__(self, name):
		self.name = name
	def __repr__(self):
		return "I am " + self.name
cat1 = Cat('cat1')
cat2 = Cat('cat2')

d = {}
d['cat1'] = cat1
print(d)
cat1.name = 'iamcat1'
print(d)