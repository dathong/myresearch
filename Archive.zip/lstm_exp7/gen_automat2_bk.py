import networkx as nx
import matplotlib.pyplot as plt
from utils import draw_automat
from utils import get_active_states
from utils import automat_gen_string
from utils import convert_data_x
import tensorflow as tf
import numpy as np
from utils import automat_gen_string_bfs
from utils import automat_gen_string_dfs1
from utils import automat_gen_string_bfs2
from scipy.special import softmax
import pickle

class State(object):
	def __init__(self, name='X', prefix=set(), suffix=set(),transition = {},pre_states = {}):
		self.name = name
		self.prefix = prefix
		self.suffix = suffix
		self.transition = transition
		self.pre_states = pre_states

	def add_prefix(self, pre):
		self.prefix.add(pre)

	def add_suffix(self,suff):
		self.suffix.add(suff)

	def add_transition(self,char,state):
		self.transition[char] = state


def merge_state(state1,state2,automata,mergeDict = {'P':'P'}):
	# state2.name += "-" + state1.name
	print('merging state...')
	if 'P' in state1.name or 'P' in state2.name:
		return
	if state1.name == state2.name:
		return state1
	if state1 in mergeDict or state1.name == 'Start':
		state1, state2 = state2, state1


	state2.prefix = state2.prefix.union(state1.prefix)
	state2.suffix = state2.suffix.union(state1.suffix)
	if state2.name == 'Start':
		state2.prefix = set()

	for p in state1.pre_states:
		state2.pre_states[p] = state1.pre_states[p]
		automata.states[p].transition[state1.pre_states[p]] = state2

	if state2 in mergeDict:
		return state2

	for t in state1.transition:
		if t not in state2.transition:
			state2.transition[t] = state1.transition[t]
		else:
			mergeDict[state1] = state2
			mergeDict[state2] = state2
			print('calling,,,')
			merge_state(state1.transition[t],state2.transition[t],automata, mergeDict)


	print('done merging')
	return state2

def merge_state_prefix(state1,state2,automata):
	# state2.name += "-" + state1.name
	state2.prefix = state2.prefix.union(state1.prefix)
	state2.suffix = state2.suffix.union(state1.suffix)
	if state2.name == 'Start':
		state2.prefix = set()

	# for t in state1.transition:
	# 	state2.transition[t] = state1.transition[t]
	for p in state1.pre_states:
		state2.pre_states[p] = state1.pre_states[p]
		automata.states[p].transition[state1.pre_states[p]] = state2
	print('done merging')
	return state2

class Automata(object):
	# Initializer / Instance Attributes
	def __init__(self, start_state=None, accepted_states=[]):
		self.start_state = start_state
		self.states = {self.start_state.name:self.start_state}
		self.accepted_states = accepted_states

	def add_states(self,state):
		self.states[state.name] = state

	def set_start_state(self,start_state_name):
		self.start_state = start_state_name

	def set_accepted_states(self,accepted_states_name):
		self.accepted_states = accepted_states_name

	def add_transition(self,from_state,char,to_state):
		if from_state.name not in self.states:
			self.states[from_state.name] = {}
		if to_state.name not in self.states:
			self.states[to_state.name] = {}
		self.states[from_state.name][char] = to_state


	def proceed(self,w):
		current_state = self.start_state
		for c in w:
			next_state = self.states[current_state][c]
			current_state = next_state
		return current_state

	def is_accepted(self,state_name):
		return state_name in self.accepted_states

	def draw(self):
		pass

def pick_min_state(stateList):
	minState = stateList[0]
	for state in stateList:
		if len(state.prefix) + len(state.suffix) < len(minState.prefix) + len(minState.suffix):
			minState = state
	return minState

def pick_min_state1(state1,state2):
	# len1 = len(state1.prefix) + len(state1.suffix)
	# len2 = len(state2.prefix) + len(state2.suffix)
	minpref1, minsuff1, minpref2, minsuff2 = 0,0,0,0
	if len(state1.prefix) >0 :
		minpref1 = min([len(pref) for pref in state1.prefix])
	if len(state1.suffix) >0 :
		minsuff1 = min([len(suff) for suff in state1.suffix])
	if len(state2.prefix) >0 :
		minpref2 = min([len(pref) for pref in state2.prefix])
	if len(state2.suffix) >0 :
		minsuff2 = min([len(suff) for suff in state2.suffix])

	if minpref1 +  minsuff1 < minpref2 + minsuff2:
		return state2, state1
	else:
		return state1,state2


if __name__ == "__main__":

	print('----building the model----')

	state_size = 2
	num_classes = 2
	batch_size = 1
	alphabets = [1, 0]
	num_layers = 1

	print('-----')

	batchX_placeholder = tf.compat.v1.placeholder(tf.float32, [batch_size, None, len(alphabets)])
	# batchY_placeholder = tf.placeholder(tf.int32, [batch_size, truncated_backprop_length])
	y_lbl_placeholder = tf.compat.v1.placeholder(tf.int64, [None, num_classes])

	W2 = tf.Variable(np.random.rand(state_size, num_classes), dtype=tf.float32)
	b2 = tf.Variable(np.zeros((1, num_classes)), dtype=tf.float32)

	# Unpack columns
	# inputs_series = tf.split(batchX_placeholder, tf.shape(batchX_placeholder)[1], axis=1)
	# labels_series = tf.unstack(batchY_placeholder, axis=1)

	# Forward passes
	lstm = tf.contrib.rnn.BasicLSTMCell(state_size)
	cell = tf.contrib.rnn.MultiRNNCell([lstm for _ in range(num_layers)])
	init_state = cell.zero_state(batch_size, tf.float32)

	states_series, current_state = tf.nn.dynamic_rnn(cell, batchX_placeholder, initial_state=init_state)

	logits_series = tf.matmul(tf.squeeze(states_series, axis=0), W2)
	prediction_series = tf.nn.softmax(logits_series, axis=1)

	# logits_series = [tf.matmul(state, W2) + b2 for state in states_series] #Broadcasted addition
	# predictions_series = [tf.nn.softmax(logits) for logits in logits_series]

	output_logits = logits_series[-1]
	y_pred = prediction_series[-1]

	# losses = [tf.nn.sparse_softmax_cross_entropy_with_logits(logits, labels) for logits, labels in zip(logits_series,labels_series)]
	# losses = [tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels, logits=logits)
	#             for logits, labels in zip(logits_series,labels_series)]

	loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=y_lbl_placeholder, logits=output_logits),
						  name='loss')

	# total_loss = tf.reduce_mean(losses)

	train_step = tf.compat.v1.train.AdagradOptimizer(0.3).minimize(loss)

	print('-----')


	sess = tf.compat.v1.Session()
	sess.run(tf.compat.v1.initialize_all_variables())
	saver = tf.compat.v1.train.Saver()
	saver.restore(sess, './my_test_model')


	def verify_automata(sess,automat, startState):
		print('[db] generating strings...')
		startName = 'Start'
		startState = automat.states[startName]
		# stringList = automat_gen_string_bfs(startState)
		stringList, unfinishedPaths = automat_gen_string_bfs2(startState)
		print('[db] checking strings...')
		if len(stringList) == 0:
			return False
		for s in stringList:
			seq = s.split("-")[1:-1]
			x = np.array(convert_data_x([seq]))
			_loss, _states_series, _current_state, _y_pred, _logits_series = sess.run(
				[loss, states_series, current_state, y_pred, logits_series],
				feed_dict={
					batchX_placeholder: x,
					y_lbl_placeholder: [[1,0]],

				})
			logit_series_sm = softmax(_logits_series, axis=1)
			for l in logit_series_sm[:-1][:,0]:
				if l > 0.9:
					return False
			if logit_series_sm[-1][0] < 0.5:
				return False

		for s in unfinishedPaths:
			seq = s.split("-")[1:-1]
			x = np.array(convert_data_x([seq]))
			_loss, _states_series, _current_state, _y_pred, _logits_series = sess.run(
				[loss, states_series, current_state, y_pred, logits_series],
				feed_dict={
					batchX_placeholder: x,
					y_lbl_placeholder: [[1, 0]],

				})
			logit_series_sm = softmax(_logits_series, axis=1)
			for l in logit_series_sm[:, 0]:
				if l > 0.9:
					return False
			if logit_series_sm[-1][0] < 0.5:
				return False

		return True

	def get_state_point(sess,state):
		seq = list(state.prefix)[0].split("-")
		x = np.array(convert_data_x([seq]))
		_loss, _states_series, _current_state, _y_pred, _logits_series = sess.run(
				[loss, states_series, current_state, y_pred, logits_series],
				feed_dict={
					batchX_placeholder: x,
					y_lbl_placeholder: [[1,0]],

				})
		return _current_state[0][1][0]


	def shortest_pre(state):
			min_pre = 99999
			res = ""
			for pre in state.prefix:
				if len(pre) < min_pre:
					min_pre = len(pre)
					res = pre
			return res

	def insert_prefix(state_name, prefix,prefixDict):
			prefixDict[prefix] = state_name


	def insert_suffix(state_name,suffix,suffixDict):
			if suffix not in suffixDict:
				suffixDict[suffix] = [state_name]
			else:
				suffixDict[suffix].append(state_name)

	def find_closest_states(state,stateList):
		if len(stateList) == 0:
			return state
		min_state = stateList[0]
		min_d = 9999
		for l_state in stateList:
			if np.linalg.norm(state.point - l_state.point) < min_d:
				min_d = np.linalg.norm(state.point - l_state.point)
				min_state = l_state
		return min_state

	def candidate_merge(currState, closestState):
			if np.linalg.norm(currState.point - closestState.point) <= 0.6*avgClusterDist:
				return True
			return False



	print('-----')

	inpf = open('path_file.txt', 'r')
	prefixDict = {}
	suffDict = {}
	suffDictSet = {}
	count = 1
	print('---start state---')
	startState = State(name='Start',prefix=set(), suffix=set(),transition = {},pre_states = {})
	startState.point = np.array([0,0])

	with open('./avgClusterDist', 'rb') as fp:
		avgClusterDist = pickle.load(fp)

	myAutomat = Automata(start_state=startState)
	newLine = True
	for line in inpf:
		print('line = ',line)
		newLine = False
		# line1 = line.split(".")
		stateTrans = line[2:].strip().split("-")

		# pre = stateTrans[0]
		# suff = "".join(stateTrans[1:])
		startState.add_suffix("-".join(stateTrans[:]))
		suffDictSet = {k: v for k, v in suffDictSet.items() if v != startState.name}
		suffDictSet[frozenset(startState.suffix)] = startState.name
		insert_suffix(startState.name,"-".join(stateTrans[:]), suffDict) 
		# prevState = State(name=str(count), prefix=set(pre), suffix=set(suff),pre_states={startState.name: [pre]})
		# myAutomat.add_transition(startState,pre,prevState)
		myAutomat.add_states(startState)
		prevState = startState

		# draw_automat(myAutomat)


		for i in range(1,len(stateTrans)):
			# pre = "-".join(stateTrans[:i])
			if prevState.name == 'Start':
				pre = stateTrans[i - 1]
			else:
				pre = shortest_pre(prevState) + "-" + stateTrans[i - 1]
			suff = "-".join(stateTrans[i:])

			stateName = str(count)
			if i == len(stateTrans) - 1:
				stateName = 'P'
			currState = State(name=stateName,prefix=set(), suffix=set(),transition = {},pre_states = {})

			currState.add_prefix(pre)
			currState.add_suffix(suff)
			prevState.add_transition(stateTrans[i - 1],currState)
			currState.pre_states = {prevState.name:stateTrans[i - 1]}
			currState.point = get_state_point(sess,currState)
			# if suff == 'P':
			# 	currState.add_transition(stateTrans[i],currState)
			myAutomat.add_states(prevState)
			myAutomat.add_states(currState)


			mergeSuffix = False
			mergedState = currState

			if pre in prefixDict:
				# prefixDict[pre].append(count)
				#---merge---
				# mergeToState = pick_min_state(currState,pre)
				# prefixDict[pre] = str(mergeToState.name)
				# state1,state2 = pick_min_state1(currState,myAutomat.states[prefixDict[pre]])
				mergedState = merge_state_prefix(currState,myAutomat.states[prefixDict[pre]],myAutomat)
				currState = mergedState
				# suffDictSet = {k: v for k, v in suffDictSet.items() if v != state1.name}
				# prefixDict = {k: v for k, v in prefixDict.items() if v != state1.name}
	

			if suff in suffDict:
				# mergeToState = pick_min_state([currState] + suffDict[suff])
				# suffDict[suff] = str(mergeToState.name)
				# state1,state2 = pick_min_state1(currState,myAutomat.states[suffDict[suffix]])
				print('[db] merging suffix...')
				print('[db] finding closest states...')
				closestState = find_closest_states(currState, [myAutomat.states[s] for s in suffDict[suff]])
				# backup
				with open('./startState', 'wb') as fp:
					pickle.dump(startState, fp)
				with open('./myAutomat', 'wb') as fp:
					pickle.dump(myAutomat, fp)
				with open('./closestState', 'wb') as fp:
					pickle.dump(closestState, fp)
				with open('./currState', 'wb') as fp:
					pickle.dump(currState, fp)
				if candidate_merge(currState, closestState):
					print('[db] passed cand merges...')
					mergedState = merge_state(currState,closestState, myAutomat)
					mergeSuffix = True
					print('[db] verifying merges...')
					if not verify_automata(sess,myAutomat,startState):
						print('[db] did not pass verifying merge...')
						with open('./startState', 'rb') as fp:
							startState = pickle.load(fp)
						with open('./myAutomat', 'rb') as fp:
							myAutomat = pickle.load(fp)
						with open('./closestState', 'rb') as fp:
							closestState = pickle.load(fp)
						with open('./currState', 'rb') as fp:
							currState = pickle.load(fp)
						mergeSuffix = False
						mergedState = currState

			print('[db] done merging suffix')
				# if mergeSuffix:
				# 	prevState = mergedState
				# 	count += 1
				# 	break
				
				# currState = mergedState


			# prefixDict[pre] = mergedState.name
			insert_prefix(mergedState.name, pre, prefixDict)
			insert_suffix(mergedState.name, suff, suffDict)
			active_states = get_active_states(myAutomat,startState)
			# suffDict = {k: v for k, v in suffDict.items() if v in active_states}
			for s in suffDict:
				v = suffDict[s]
				new_v = []
				for state in v:
					if state in active_states:
						new_v.append(state)
				suffDict[s] = new_v

			suffDict = {k: v for k, v in suffDict.items() if len(v) != 0}

			prefixDict = {k: v for k, v in prefixDict.items() if v in active_states}
			# prevState = mergedState
			count+=1


			if mergeSuffix:
				prevState = mergedState
				break
			else:
				prevState = currState

		# draw_automat(myAutomat)

		# if newLine:
		# 	break

	draw_automat(myAutomat,startState)
	print('finished drawing')
	with open('./saved_automat_final', 'wb') as fp:
		pickle.dump(myAutomat, fp)
	print('------testing-----')
	startState = myAutomat.states['Start']
	stringList = automat_gen_string_bfs(startState)
	for s in stringList:
		print(s)
	print('Done')