import matplotlib.pyplot as plt
from utils import draw_automat
from utils import get_active_states
from utils import automat_gen_string
from utils import convert_data_x
import tensorflow as tf
import numpy as np
from utils import automat_gen_string_bfs
from utils import automat_gen_string_bfs1
from utils import automat_gen_string_dfs1
from utils import automat_gen_string_bfs2
from utils import automat_gen_string_bfs3
from utils import automat_gen_string_bfs4suffix
from scipy.special import softmax
import pickle


class State(object):
    def __init__(self, name='X', prefix=set(), suffix=set(), transition={}, pre_states={}):
        self.name = name
        self.prefix = prefix
        self.suffix = suffix
        self.transition = transition
        self.pre_states = pre_states

    def add_prefix(self, pre):
        self.prefix.add(pre)

    def add_suffix(self, suff):
        self.suffix.add(suff)

    def add_transition(self, char, state):
        self.transition[char] = state


def merge_state(state1, state2, automata, mergeDict={'P': 'P'}):
    # state2.name += "-" + state1.name
    # print('merging state...')
    state1 = automata.states[state1.name]
    state2 = automata.states[state2.name]

    if 'P' in state1.name:
        state1, state2 = state2,state1

    if state1 == None or state2 == None:
        return None

    if state1.name == state2.name:
        return state1

    for p in state1.pre_states:
        state2.pre_states[p] = state1.pre_states[p]
        automata.states[p].transition[state1.pre_states[p]] = state2

    if 'P' in state2.name or 'P' in state1.name:
        return

    for t in list(state1.transition):
        if state1.transition[t] == None:
            continue
        if t not in state2.transition or state2.transition[t] == None:
            # automata.states[state2.name].transition[t] = automata.states[state1.name].transition[t]
            # automata.states[automata.states[state2.name].transition[t].name].pre_states[automata.states[state2.name].name] = t
            state2.transition[t] = state1.transition[t]
            state2.transition[t].pre_states[state2.name] = t
        else:
            # print('merging recursively...')
            print('[db] merging recursively: ', state1.transition[t].name, state2.transition[t].name)
            state2.transition[t] = merge_state(state1.transition[t], state2.transition[t], automata, mergeDict)

    # print('done merging')
    return state2


def merge_state_prefix(state1, state2, automata):
    # state2.name += "-" + state1.name
    state2.prefix = state2.prefix.union(state1.prefix)
    state2.suffix = state2.suffix.union(state1.suffix)
    if state2.name == 'Start':
        state2.prefix = set()

    # for t in state1.transition:
    #     state2.transition[t] = state1.transition[t]
    for p in state1.pre_states:
        automata.states[state2.name].pre_states[p] = automata.states[state1.name].pre_states[p]
        automata.states[p].transition[state1.pre_states[p]] = state2
    # print('done merging')
    return state2



def verify_automata(sess, automat, startState):
    # print('[db] generating strings...')
    startName = 'Start'
    startState = automat.states[startName]
    # stringList = automat_gen_string_bfs(startState)
    stringList, unfinishedPaths = automat_gen_string_bfs3(startState)
    # print('[db] checking strings...')
    if len(stringList) == 0:
        return False
    d_stringList, d_unfinish_paths = {}, {}
    for s in stringList:
        seq = s.split("-")[1:-1]
        if len(seq) not in d_stringList:
            d_stringList[len(seq)] = [seq]
        else:
            d_stringList[len(seq)].append(seq)

    for s in unfinishedPaths:
        seq = s.split("-")[1:-1]
        if len(seq) not in d_unfinish_paths:
            d_unfinish_paths[len(seq)] = [seq]
        else:
            d_unfinish_paths[len(seq)].append(seq)

    for ls in d_stringList:
        x = np.array(convert_data_x(d_stringList[ls]))
        # print('x shape ',x,x.shape,np.array([[1,0]]*x.shape[1]).shape)
        _loss, _states_series, _current_state, _y_pred, _logits_series, _test_var = sess.run(
            [loss, states_series, current_state, y_pred, logits_series, test_var],
            feed_dict={
                batchX_placeholder: x,
                y_lbl_placeholder: [[1, 0]] * x.shape[0],

            })
        # print('_test_var = ')
        # for t in _test_var:
        #     print('t = ',t,t.shape)
        logit_series_sm = softmax(_logits_series, axis=2)
        if np.any(logit_series_sm[:, :-1, 0].flatten() > 0.9):
            return False
        if np.any(logit_series_sm[:, -1, 0] < 0.8):
            return False
    # for l in logit_series_sm[:-1][:,0]:
    #     if l > 0.9:
    #         return False
    # if logit_series_sm[-1][0] < 0.5:
    #     return False

    for ls in d_unfinish_paths:
        x = np.array(convert_data_x(d_unfinish_paths[ls]))
        _loss, _states_series, _current_state, _y_pred, _logits_series = sess.run(
            [loss, states_series, current_state, y_pred, logits_series],
            feed_dict={
                batchX_placeholder: x,
                y_lbl_placeholder: [[1, 0]] * x.shape[0],

            })
        logit_series_sm = softmax(_logits_series, axis=2)
        if np.any(logit_series_sm[:, :, 0].flatten() > 0.9):
            return False
    # if np.any(logit_series_sm[:,-1,0] > 0.9):
    #     return False
    # for l in logit_series_sm[:, 0]:
    #     if l > 0.9:
    #         return False
    # if logit_series_sm[-1][0] < 0.5:
    #     return False

    return True


def get_state_point(sess, state):
    seq = list(state.prefix)[0].split("-")
    if 'P' in seq:
        seq.remove('P')
    x = np.array(convert_data_x([seq]))
    _loss, _states_series, _current_state, _y_pred, _logits_series = sess.run(
        [loss, states_series, current_state, y_pred, logits_series],
        feed_dict={
            batchX_placeholder: x,
            y_lbl_placeholder: [[1, 0]],

        })
    return _current_state[0][1][0]


def shortest_pre(state):
    min_pre = 99999
    res = ""
    for pre in state.prefix:
        if len(pre) < min_pre:
            min_pre = len(pre)
            res = pre
    return res


def refresh_automat(automat, startName='Start'):
    visited = set()

    def refresh(state, visited, t="", pre_state=None, ):
        if state.name != 'Start':
            # state = automat.states[state.name]
            pre_state.transition[t] = automat.states[state.name]
        if state.name == 'P':
            return

        visited.add(state.name)
        for t in state.transition:
            if state.transition[t].name in visited:
                continue
            refresh(state.transition[t], visited, t, state)

    startState = automat.states[startName]

    refresh(startState, visited)
    return visited

def remove_inactive_states(active_states, automat):
    curr_state_names = list(automat.states.keys())
    inactive_states = []
    for state in curr_state_names:
        if state not in active_states and 'P' not in state:
            # inactive_states.append(state)
            del automat.states[state]

    for state in list(automat.states.keys()):
        for pre_state in automat.states[state].pre_states:
            if pre_state not in active_states:
                inactive_states.append((state,pre_state))
    for state_pair in inactive_states:
        del automat.states[state_pair[0]].pre_states[state_pair[1]]

def remove_states(stateName, automat):
    if stateName in automat.states:
        del automat.states[stateName]
    for state in automat.states:
        if stateName in automat.states[state].pre_states:
            del automat.states[state].pre_states[stateName]

def insert_prefix(state_name, prefix, prefixDict):
    if state_name == 'Start':
        return
    prefixDict[prefix] = state_name


def insert_suffix(state_name, suffix, suffixDict):
    if suffix not in suffixDict:
        suffixDict[suffix] = [state_name]
    else:
        suffixDict[suffix].append(state_name)


from operator import itemgetter
def find_closest_states(state, stateList):
    if len(stateList) == 0:
        return state
    stateList = [[s,np.linalg.norm(state.point - s.point)] for s in stateList]
    sorted_states = sorted(stateList,key=itemgetter(1))
    return np.array(sorted_states)[:,0]


def candidate_merge(currState, closestState):
    # if np.linalg.norm(currState.point - closestState.point) <= avgClusterDist:
    #     return True
    # return False
    return True

def add_state_pre(pre,state,startState, automat):
    added = False
    current_state = startState
    # print('[db] pre = ',pre,pre[:-1])
    for c in pre[:-1]:

        next_state = current_state.transition[c]
        current_state = next_state
    # print('pre = ',pre)
    if 'P' in pre[-1]:
        pre_P = {}
        if 'P' in automat.states:
            current_state.pre_states.update(automat.states['P'].pre_states)
        current_state.name = 'P'
        automat.add_states(current_state)
        return current_state, False
    if pre[-1] not in current_state.transition or current_state.transition[pre[-1]] == None:
         current_state.transition[pre[-1]] = state
         state.pre_states[current_state.name] = pre[-1]
         automat.add_states(state)
         added = True
    # print('[db] state, added = ',state,added)
    return state, added

class Automata(object):
    # Initializer / Instance Attributes
    def __init__(self, start_state=None, accepted_states=[]):
        self.start_state = start_state
        self.states = {self.start_state.name: self.start_state}
        self.accepted_states = accepted_states

    def add_states(self, state):
        self.states[state.name] = state

    def set_start_state(self, start_state_name):
        self.start_state = start_state_name

    def set_accepted_states(self, accepted_states_name):
        self.accepted_states = accepted_states_name

    def add_transition(self, from_state, char, to_state):
        if from_state.name not in self.states:
            self.states[from_state.name] = {}
        if to_state.name not in self.states:
            self.states[to_state.name] = {}
        self.states[from_state.name][char] = to_state

    def proceed(self, w):
        current_state = self.start_state
        for c in w:
            next_state = self.states[current_state][c]
            current_state = next_state
        return current_state

    def is_accepted(self, state_name):
        return state_name in self.accepted_states

    def draw(self):
        pass
    
    


if __name__ == "__main__":

    import os

    os.system('rm ./automat_fol/*_gv*')

    print('----building the model----')

    state_size = 10
    num_classes = 2
    batch_size = 1
    alphabets = [1, 0]
    num_layers = 1

    print('-----')

    batchX_placeholder = tf.compat.v1.placeholder(tf.float32, [None, None, len(alphabets)])
    # batchY_placeholder = tf.placeholder(tf.int32, [batch_size, truncated_backprop_length])
    y_lbl_placeholder = tf.compat.v1.placeholder(tf.int64, [None, num_classes])

    W2 = tf.Variable(np.random.rand(state_size, num_classes), dtype=tf.float32)
    b2 = tf.Variable(np.zeros((1, num_classes)), dtype=tf.float32)

    # c_tile = tf.constant(x)
    W_tile = tf.tile(tf.expand_dims(W2, axis=0), [tf.shape(batchX_placeholder)[0], 1, 1])
    # Unpack columns
    # inputs_series = tf.split(batchX_placeholder, tf.shape(batchX_placeholder)[1], axis=1)
    # labels_series = tf.unstack(batchY_placeholder, axis=1)

    # Forward passes
    lstm = tf.contrib.rnn.BasicLSTMCell(state_size)
    cell = tf.contrib.rnn.MultiRNNCell([lstm for _ in range(num_layers)])
    init_state = cell.zero_state(tf.shape(batchX_placeholder)[0], tf.float32)

    states_series, current_state = tf.nn.dynamic_rnn(cell, batchX_placeholder, initial_state=init_state)

    # logits_series = tf.matmul(tf.squeeze(states_series,axis=0),W2)
    logits_series = tf.matmul(states_series, W_tile)
    prediction_series = tf.nn.softmax(logits_series, axis=2)

    # logits_series = [tf.matmul(state, W2) + b2 for state in states_series] #Broadcasted addition
    # predictions_series = [tf.nn.softmax(logits) for logits in logits_series]

    output_logits = logits_series[:, -1, :]
    y_pred = prediction_series[:, -1, :]

    # losses = [tf.nn.sparse_softmax_cross_entropy_with_logits(logits, labels) for logits, labels in zip(logits_series,labels_series)]
    # losses = [tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels, logits=logits)
    #             for logits, labels in zip(logits_series,labels_series)]
    test_var = [y_lbl_placeholder, logits_series, output_logits]
    loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=y_lbl_placeholder, logits=output_logits),
                          name='loss')

    # total_loss = tf.reduce_mean(losses)

    train_step = tf.compat.v1.train.AdagradOptimizer(0.3).minimize(loss)

    print('-----')

    sess = tf.compat.v1.Session()
    sess.run(tf.compat.v1.initialize_all_variables())
    saver = tf.compat.v1.train.Saver()
    saver.restore(sess, './my_test_model')



    print('-----')

    inpf = open('path_file.txt', 'r')
    with open('./avgClusterDist', 'rb') as fp:
        avgClusterDist = pickle.load(fp)

    count = 1
    linecount = 1
    maxlinecount = 20
    print('---start state---')
    alphabet = ['1','0']
    startTransition = {a:None for a in alphabet}
    startState = State(name='Start', prefix=set(), suffix=set(), transition=startTransition, pre_states={})
    startState.point = np.array([0] * state_size)
    myAutomat = Automata(start_state=startState)
    newLine = True
    myAutomat.add_states(startState)
    for line in inpf:
        line_arr = line.split("-")[1:]
        addedStates = []
        if linecount == 5:
            print('we are here')
        for idx, tran in enumerate(line_arr):
            pre = line_arr[:idx + 1]
            stateName = str(count)
            # print('pre = ',pre, pre[-1])
            # if 'P' in pre[-1]:
            #     stateName = 'P'
            currState = State(name=stateName, prefix=set(), suffix=set(), transition={}, pre_states={})
            currState.add_prefix("-".join(pre).replace("-P\n",""))
            currState.point = get_state_point(sess, currState)
            addedState, added = add_state_pre(pre,currState,myAutomat.states['Start'], myAutomat)
            if added:
                addedStates.append(addedState.name)
                myAutomat.add_states(currState)
            count+=1
        activeStates = get_active_states(myAutomat, startState)
        while len(addedStates) > 0:
            state1 = myAutomat.states[addedStates[0]]
            closestStates = find_closest_states(state1, \
                                               [myAutomat.states[s] for s in activeStates \
                                                if s != state1.name])

            for closestState in closestStates:

                if True \
                        and state1.name == '10' \
                        :
                        # and closestState.name == '1' \
                        # :


                    print('we are here')
                print('[db] linecount, state1.name, closestState.name ',linecount, state1.name,closestState.name)
                with open('./startState', 'wb') as fp:
                    pickle.dump(startState, fp)
                with open('./myAutomat', 'wb') as fp:
                    pickle.dump(myAutomat, fp)
                # with open('./state1', 'wb') as fp:
                #     pickle.dump(state1, fp)

                if candidate_merge(state1, closestState):
                    print('[db] ready to merge: ',state1.name,closestState.name)
                    mergedState = merge_state(state1,closestState,myAutomat)
                    # with open('./debug_myAutomat', 'wb') as fp:
                    #     print('[db] draw DB Automat with pre = ', pre)
                    #     draw_automat(myAutomat, startState, name="./automat_fol/" + \
                    #                                              str(linecount) + "_[db]DB_" + str(
                    #         pre) + "_" + line)
					#
                    #     pickle.dump(myAutomat, fp)
                    mergeSuffix = True
                    if not verify_automata(sess, myAutomat, startState):
                        # print('[db] did not pass verifying merge...')
                        with open('./startState', 'rb') as fp:
                            startState = pickle.load(fp)
                        with open('./myAutomat', 'rb') as fp:
                            myAutomat = pickle.load(fp)
                        # with open('./state1', 'rb') as fp:
                        #     state1 = pickle.load(fp)
                        state1 = myAutomat.states[addedStates[0]]
                        # closestState = myAutomat.states[closestState.name]
                        mergeSuffix = False
                    if mergeSuffix:
                        print('[db] addedStates, state1 : ',addedStates, state1.name)
                        # activeStates = get_active_states(myAutomat, startState)
                        # addedStates = [name for name in addedStates if name in activeStates]
                        if state1.name in addedStates:
                            addedStates.remove(state1.name)
                        #     # remove_states(state1.name,myAutomat)
                        remove_states(state1.name,myAutomat)
                        # remove_inactive_states(activeStates,myAutomat)
                        break
            activeStates = get_active_states(myAutomat, startState)
            addedStates = [name for name in addedStates if name in activeStates]
            if state1.name in addedStates:
                addedStates.remove(state1.name)
                # remove_states(state1.name,myAutomat)
            # remove_states(state1.name, myAutomat)
            remove_inactive_states(activeStates, myAutomat)

        draw_automat(myAutomat, startState, name="./automat_fol/" + \
													 str(linecount) + "_[db]Endline" + str(pre) + "_" + line)

        linecount+=1
    print('Done')

