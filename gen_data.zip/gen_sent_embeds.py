import pandas as pd
import numpy as np
import tensorflow as tf
import pickle
tf.compat.v1.disable_eager_execution()
from sentence_transformers import SentenceTransformer, LoggingHandler

#/Users/dathong/PycharmProjects/myresearch/Movie-Reviews-Sentiment-master/unlabeledTrainData.tsv

# Load the data
with open ('./train_clean', 'rb') as fp:
    train_clean = pickle.load(fp)

with open ('./valid_clean', 'rb') as fp:
	valid_clean = pickle.load(fp)

with open ('./mytest_clean', 'rb') as fp:
	my_test_clean = pickle.load(fp)

print(train_clean[:5])
print(valid_clean[:5])
print(my_test_clean[:5])

print(train_clean[0])

train_sents, valid_sents, my_test_sents = [], [], []

def gen_sents(para):
	res = []
	for p in para:
		sents = p.split(".")
		res.append(sents)
	return res

train_sents = gen_sents(train_clean)
valid_sents = gen_sents(valid_clean)
my_test_sents = gen_sents(my_test_clean)

def process_sents(sents):
	count1, count2 = 0, 0
	sent_list = []
	p_to_sent = {}
	sent_to_p = {}
	for p in sents:
		p_to_sent[count2] = []
		for sent in p:
			sent_list.append(sent)
			p_to_sent[count2].append(count1)
			sent_to_p[count1] = count2
			count1+=1
		count2+=1
	return sent_list, p_to_sent, sent_to_p

train_sent_list, train_p_to_sent, train_sent_to_p = process_sents(train_sents)
valid_sent_list, valid_p_to_sent, valid_sent_to_p = process_sents(valid_sents)
mytest_sent_list, mytest_p_to_sent, mytest_sent_to_p = process_sents(my_test_sents)

print("train_sent_list len = ",len(train_sent_list), len(valid_sent_list))

def get_test_batches(x, batch_size):
    '''Create the batches for the testing data'''
    n_batches = len(x)//batch_size
    x = x[:n_batches*batch_size]
    for ii in range(0, len(x), batch_size):
        yield x[ii:ii+batch_size]



print('----generating----')
print('my_test_sents = ',my_test_sents)

module_url = "/Users/dathong/Desktop/Bin/UniversityOfIowa/deep_learning/research/1"
# Import the Universal Sentence Encoder's TF Hub module
model = SentenceTransformer('bert-base-nli-mean-tokens')

# with tf.compat.v1.Session() as session:
# 	session.run([tf.compat.v1.global_variables_initializer(), tf.compat.v1.tables_initializer()])
def gen_sent_embed(sent_list, p_to_sent,fname):
		res = []
		# for i, x in enumerate(get_test_batches(train_sent_list,5000)):
		print('generating...)')
		# sentences_embeddings = session.run(embed(sent_list))
		# sentences = ['This framework generates embeddings for each input sentence',
		# 			 'Sentences are passed as a list of string.',
		# 			 'The quick brown fox jumps over the lazy dog.']
		sentence_embeddings = model.encode(sent_list)
		print('sentences_embeddings = ',len(sentence_embeddings))

		with open(fname, 'wb') as fp:
			pickle.dump(sentence_embeddings, fp)

		res = sentence_embeddings

		results = []
		for i in range(len(p_to_sent)):
			res1 = []
			for k in p_to_sent[i]:
				res1.append(res[k])
			results.append(res1)
		
		return results


train_vects = gen_sent_embed(train_sent_list, train_p_to_sent,'train_sentences_embeddings')
valid_vects = gen_sent_embed(valid_sent_list, valid_p_to_sent,'valid_sentences_embeddings')
my_test_vects = gen_sent_embed(mytest_sent_list, mytest_p_to_sent,'mytest_sentences_embeddings')
	# print('generating...')
	# train_vects = session.run(embed(train_sents[:10]))
	# print('my_test_vects = ',my_test_vects)
print('finished')

with open('train_vects', 'wb') as fp:
		pickle.dump(train_vects, fp)

with open('valid_vects', 'wb') as fp:
		pickle.dump(valid_vects, fp)
	#
with open('my_test_vects', 'wb') as fp:
		pickle.dump(my_test_vects, fp)


print('done')