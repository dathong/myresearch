import pandas as pd
import numpy as np
# import tensorflow as tf
import nltk, re, time
from nltk.corpus import stopwords
from string import punctuation
from collections import defaultdict
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from collections import namedtuple
import os
import re
import pickle
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('bert-base-nli-mean-tokens')


def clean_text(text, remove_stopwords=True):
	'''Clean the text, with the option to remove stopwords'''

	# Convert words to lower case and split them
	text = text.lower().split()

	# Optionally, remove stop words
	if remove_stopwords:
		stops = set(stopwords.words("english"))
		stops = set(['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should', "should've", 'now', 'd', 'll', 'm', 'o', 're', 've', 'y'])
		text = [w for w in text if not w in stops]

	text = " ".join(text)

	# Clean the text
	text = re.sub(r"<br />", " ", text)
	text = re.sub(r"[^a-z.]", " ", text)
	text = re.sub(r"   ", " ", text)  # Remove any extra spaces
	text = re.sub(r"  ", " ", text)
	# Remove punctuation from text
	text = ''.join([c for c in text if (c not in punctuation) or (c == '.')])

	return (text)

import nltk
nltk.download('stopwords')

# Load the data
train_data = pd.read_csv("/Users/dathong/PycharmProjects/myresearch/Movie-Reviews-Sentiment-master/labeledTrainData.tsv", delimiter="\t")
# test_data = pd.read_csv("/Users/dathong/PycharmProjects/myresearch/Movie-Reviews-Sentiment-master/testData.tsv", delimiter="\t")
max_sent_len = 0
max_sent_count = 0
sent_lens = []
sent_counts = []
train_data1 = []
for ip in train_data.values:
  # print("ip = ",ip[2])
  # sents = ip[2].split(".")
  sents = re.split('[.?!]',ip[2])
  sents1 = []
  # sents1 = [s for s in sents if len(s) > 1]
  for s in sents:
    for ss in s.split('<br />'):
      # ss = s
      if len(ss) > 2:
        # print('ss = ',ss)
        sents1.append(ss)
  # sents = [s.split('<br />') for s in sents]
  sents2 = ".".join(sents1)
  train_data1.append(sents2)
  sent_count = 0
  # print('sents = ',sents)
  for sent in sents2.split("."):
    if len(sent.split()) > max_sent_len:
      max_sent_len = len(sent.split())
    if len(sent.split()) >= 200:
      print('sent = ',sent)
    sent_lens.append(len(sent.split()))
    sent_count+=1
    if sent_count > max_sent_count:
      max_sent_count = sent_count
  sent_counts.append(sent_count)

train_data['review1'] = train_data1

print('train_data = ',train_data)

train_review = train_data.review1

# x_review_train, x_review_valid, y_train, y_valid = train_test_split(train_review, train_data.sentiment, test_size = 0.15, random_state = 2)

x_review_train, y_train, x_review_valid, y_valid = list(train_review[:20000].values), list(train_data.sentiment[:20000].values), list(train_review[20000:].values), list(train_data.sentiment[20000:].values)

train_clean = []
train_not_clean = []
valid_not_clean = []
for review in x_review_train:
    train_clean.append(clean_text(review,remove_stopwords=False))
    train_not_clean.append(review)

valid_clean = []
for review in x_review_valid:
    valid_clean.append(clean_text(review,remove_stopwords=False))
    valid_not_clean.append(review)

with open('train_not_clean', 'wb') as fp:
	pickle.dump(train_not_clean, fp)

with open('valid_not_clean', 'wb') as fp:
	pickle.dump(valid_not_clean, fp)

my_test = ['I really love this movie. It is awesome',
           'I enjoy this movie so much. What a masterpiece. Everything is excellent, the actors are very talented',
           'This movie sucks. It is too bad. What a waste of time. It is terrible',
           'I will never watch it again. Why the actors are so bad',
           'I think this movie is fine']

mytest_clean = []
for review in my_test:
	mytest_clean.append(clean_text(review,remove_stopwords=False))

with open('train_clean', 'wb') as fp:
	pickle.dump(train_clean, fp)

with open('valid_clean', 'wb') as fp:
	pickle.dump(valid_clean, fp)

with open('y_train', 'wb') as fp:
	pickle.dump(y_train, fp)

with open('y_valid', 'wb') as fp:
	pickle.dump(y_valid, fp)

with open('mytest_clean', 'wb') as fp:
	pickle.dump(mytest_clean, fp)

print('mytest_clean = ',mytest_clean)
print('done')